package poo;

public class SmartDevice {

	String software;
	int numCamaras;
	boolean gps;
	
	public SmartDevice() {
		
	}
	public SmartDevice(String software, int numCamaras, boolean gps) {
		this.software = software;
		this.numCamaras = numCamaras;
		this.gps = gps;
	}
	
}
