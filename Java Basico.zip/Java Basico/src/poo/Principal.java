package poo;

public class Principal {
	
	public static void main(String[] args) {
		
		SmartPhone GalaxyA12 = new SmartPhone("Android",2,true,6,250);
		 System.out.println(GalaxyA12.almacenamiento);
		 System.out.println(GalaxyA12.gps);
		 System.out.println(GalaxyA12.numCamaras);
		 System.out.println(GalaxyA12.numRam);
		 System.out.println(GalaxyA12.software);
		 
		 SmartWatch iwatch = new SmartWatch("ios", 1, false, 225, true);
		 System.out.println(iwatch.software);
		 System.out.println(iwatch.numCamaras);
		 System.out.println(iwatch.llamadas);
		 System.out.println(iwatch.gps);
		 System.out.println(iwatch.contadorDePasos);
	}

}
