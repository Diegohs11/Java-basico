package poo;

public class SmartPhone extends SmartDevice {

	int numRam;
	int almacenamiento;
	
	public SmartPhone() {
		
	}
	
	public SmartPhone(String software, int numCamaras, boolean gps, int numRam, int almcenamiento) {
		super(software, numCamaras, gps);
		this.numRam = numRam;
		this.almacenamiento = almcenamiento;
		
	}
	
}
