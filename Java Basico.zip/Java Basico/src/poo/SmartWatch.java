package poo;

public class SmartWatch extends SmartDevice {

	int contadorDePasos;
	boolean llamadas;
	
	public SmartWatch() {
		
	}
	
	public SmartWatch(String software, int numCamaras, boolean gps, int contadorDePasos, boolean llamdas) {
		super(software, numCamaras, gps);
		
	}
	
}
